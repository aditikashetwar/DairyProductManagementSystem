package com.dairyproducts.DairyProductManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DairyProductManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
