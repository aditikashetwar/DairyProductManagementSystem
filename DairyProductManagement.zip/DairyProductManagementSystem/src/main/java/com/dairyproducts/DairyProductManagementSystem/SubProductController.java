package com.dairyproducts.DairyProductManagementSystem;
import java.util.Arrays;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("dairysubproduct")
public class SubProductController {
	@Autowired
	SessionFactory sessionfactory;
	
	@PostMapping("dairy/{Did}")
	public SubProduct addproducts(@RequestBody SubProduct products,@PathVariable int Did) {
		Session session=sessionfactory.openSession();
		DairyProduct dairyproduct=session.load(DairyProduct.class, Did);
		List<SubProduct>productlist=dairyproduct.getProducts();
		Transaction transaction=session.beginTransaction();
		productlist.add(products);
		transaction.commit();
		
		
		return products;
	}
	
	@GetMapping("dairy/{pid}")
	public String viewProduct(@PathVariable int pid) {
		Session session=sessionfactory.openSession();
		NativeQuery<Object[]>query=session.createSQLQuery("select subproduct.pid,subproduct.name,subproduct.price,dairyproduct.Did,dairyproduct.Name as dname from dairyproduct,subproduct where subproduct.Did=dairyproduct.Did and  pid="+pid);
				List<Object[]>list=query.list();
				Object[]array=list.get(0);
				
		return Arrays.toString(array);
		
	}
	@GetMapping("dairy")
	public String getAllProduct() {
		Session session=sessionfactory.openSession();
		NativeQuery<Object[]>query=session.createSQLQuery("select subproduct.pid,subproduct.name,subproduct.price,dairyproduct.Did,dairyproduct.Name as dname from dairyproduct,subproduct where subproduct.Did=dairyproduct.Did");
				List<Object[]>list=query.list();
		StringBuffer stringbuffer=new StringBuffer();
		for(int i=0;i<list.size();i++) {
			Object[]array=list.get(i);
			stringbuffer.append(Arrays.toString(array)+",");
		}
		return stringbuffer.toString();
	}
	
	@DeleteMapping("dairy/{pid}")
	public String deleteProduct(@PathVariable int pid) {
		Session session =sessionfactory.openSession();
		NativeQuery<Object[]>query=session.createSQLQuery("select DairyProduct.Did,DairyProduct.Name from DaityProduct,SubProduct where SubProduct.Did=DairyProduct.Did and pid="+pid);
		List<Object[]>list=query.list();
		Object[]array=list.get(0);
		int Did=(int)array[0];
		DairyProduct dairyproduct=session.load(DairyProduct.class, Did);
		List<SubProduct>productlist=dairyproduct.getProducts();
		
		SubProduct subproduct=session.load(SubProduct.class, pid);
		Transaction transaction=session.beginTransaction();
		productlist.remove(subproduct);
		transaction.commit();
		
		return "record deleted";
	}
	
	@PutMapping("dairy")
	public String updateProduct(@RequestBody SubProduct clientproduct) {
		Session session=sessionfactory.openSession();
		SubProduct subproduct=session.load(SubProduct.class, clientproduct.getPid());
		subproduct.setName(clientproduct.getName());
		subproduct.setPrice(clientproduct.getPrice());
		
		Transaction transaction=session.beginTransaction();
		session.update(subproduct);
		
		transaction.commit();
		return "record Updated ";
	}

}
