package com.dairyproducts.DairyProductManagementSystem;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("dairyproductapi")
public class DairyProductController {
	
	@Autowired
	SessionFactory sessionfactory;
	
	@GetMapping("dairyproduct/{Did}")
	public DairyProduct getdairyproducts(@PathVariable int Did) {
		Session session=sessionfactory.openSession();
		DairyProduct dairyproduct=session.load(DairyProduct.class,Did);
		return dairyproduct;
		
	}
	
	@GetMapping("dairyproduct")
	public List<DairyProduct> getallDairyProducts(){
		Session session =sessionfactory.openSession();
		Query query=session.createQuery("from DairyProduct");
		List<DairyProduct>list=query.list();
		return list;
	}
	
	@PostMapping("dairyproduct")
	public DairyProduct addproduct(@RequestBody DairyProduct dairyproduct) {
		Session session=sessionfactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(dairyproduct);
		
		transaction.commit();
      return dairyproduct;
	}
	
     @DeleteMapping("dairyproduct/{Did}")
	public String deleteproduct(@PathVariable int Did) {
    	 Session session=sessionfactory.openSession();
    	 DairyProduct dairyproduct=session.load(DairyProduct.class,Did);
    	 Transaction transaction=session.beginTransaction();
    	 session.delete(dairyproduct);
    	 transaction.commit();
    	 
    	 return "record deleted";
	}
     
     @PutMapping("dairyproduct")
     public String updatedairyproduct(@RequestBody DairyProduct clientcategory) {
    	 Session session =sessionfactory.openSession();
    	 
    	 DairyProduct dairyproduct=session.load(DairyProduct.class, clientcategory.getDid());
    	 
    	 clientcategory.setManufacturingDate(clientcategory.getManufacturingDate());
    	 clientcategory.setName(clientcategory.getName());
    	 clientcategory.setPrice(clientcategory.getPrice());
    	 clientcategory.setShelfLifeMonths(clientcategory.getShelfLifeMonths());
    	 
    	 Transaction transaction=session.beginTransaction();
    	 session.update(dairyproduct);
    	 
    	 
    	 transaction.commit();
    	 return "record updated";
     }
     
     
     
}
