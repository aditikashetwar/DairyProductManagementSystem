package com.dairyproducts.DairyProductManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DairyProductManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DairyProductManagementSystemApplication.class, args);
	}

}
