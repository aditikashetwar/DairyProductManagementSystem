package com.dairyproducts.DairyProductManagementSystem;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
@Entity
public class DairyProduct {
	@Id
	int Did;
	String Name;
	int Price;
	int ShelfLifeMonths;
	String ManufacturingDate;
	
	@OneToMany(targetEntity=SubProduct.class,cascade=CascadeType.ALL,orphanRemoval=true)
	@JoinColumn(name="Did")
	
	List<SubProduct>products;

	public int getDid() {
		return Did;
	}

	public void setDid(int did) {
		Did = did;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

	public int getShelfLifeMonths() {
		return ShelfLifeMonths;
	}

	public void setShelfLifeMonths(int shelfLifeMonths) {
		ShelfLifeMonths = shelfLifeMonths;
	}

	public String getManufacturingDate() {
		return ManufacturingDate;
	}

	public void setManufacturingDate(String manufacturingDate) {
		ManufacturingDate = manufacturingDate;
	}

	public List<SubProduct> getProducts() {
		return products;
	}

	public void setProducts(List<SubProduct> products) {
		this.products = products;
	}

	public DairyProduct(int did, String name, int price, int shelfLifeMonths, String manufacturingDate,
			List<SubProduct> products) {
		super();
		Did = did;
		Name = name;
		Price = price;
		ShelfLifeMonths = shelfLifeMonths;
		ManufacturingDate = manufacturingDate;
		this.products = products;
	}

	public DairyProduct() {
		super();
	}

	@Override
	public String toString() {
		return "DairyProduct [Did=" + Did + ", Name=" + Name + ", Price=" + Price + ", ShelfLifeMonths="
				+ ShelfLifeMonths + ", ManufacturingDate=" + ManufacturingDate + ", products=" + products + "]";
	}
	
	
	
	

}
